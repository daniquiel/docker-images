from helpers import get_item_by_name
from items import USABLE


def _exec(context: dict, param: str):
    name = param

    if not name:
        print("Neviem, aký predmet chceš použiť.")
        return

    # search for item in room or backpack
    item = get_item_by_name(name, context['room']['items'] + context['backpack']['items'])

    # item is not found
    if item is None:
        print('Taký predmet tu nikde nevidím.')
        return

    # item is not usable
    if USABLE not in item['features']:
        print('Tento predmet sa nedá použiť.')
        return

    if 'use' not in item:
        raise NotImplementedError('Not yet implemented')

    # save to history
    context['history'].append(f'{cmd["name"]} {param}')

    print(f"Používam predmet {item['name']}")
    item['use'](context)


cmd = {
    'name': 'pouzi',
    'description': 'ak sa predmet dá použiť, vykoná s ním príslušnú akciu',
    'aliases': ('use',),
    'exec': _exec
}
