def _exec(context: dict, param: str):
    print("(c) 2021 buduci pythonista Daniel")


cmd = {
    'name': 'o hre',
    'description': 'zobrazí informácie o hre',
    'aliases': ('about', 'info', 'o hre'),
    'exec': _exec
}
