from helpers import get_item_by_name
from items import MOVABLE


def _exec(context: dict, param: str):
    backpack = context['backpack']
    room = context['room']
    name = param

    # name of the item was not entered
    if not name:
        print("Neviem, čo chceš zobrať.")
        return

    # search for item in room items
    item = get_item_by_name(name, room['items'])

    # item was not found
    if item is None:
        print("Taký predmet tu nikde nevidím.")
        return

    # item is not movable
    if MOVABLE not in item['features']:
        print('Tento predmet sa nedá vziať.')
        return

    # check if backpack is not full
    if len(backpack['items']) >= backpack['max']:
        print('Batoh je plný.')
        return

    # save to history
    context['history'].append(f'{cmd["name"]} {param}')

    # take item
    room['items'].remove(item)
    backpack['items'].append(item)
    print(f"Predmet {name} si si vložil do batohu.")


cmd = {
    'name': 'vezmi',
    'description': 'zoberie vec z miestnosti a uloží ju do batohu',
    'aliases': ('zober',),
    'exec': _exec
}
