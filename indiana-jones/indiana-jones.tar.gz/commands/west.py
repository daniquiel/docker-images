from helpers import get_room_by_name, show_room


def _exec(context: dict, param: str):
    room_exit = context['room']['exits']['west']
    if room_exit is None:
        print('Tam sa nedá ísť.')
        return

    # save to history
    context['history'].append(f'{cmd["name"]} {param}')

    context['room'] = get_room_by_name(context['world'], room_exit)
    show_room(context['room'])


cmd = {
    'name': 'zapad',
    'description': 'presunie sa z miestnosti na západ',
    'aliases': ('west',),
    'exec': _exec
}
