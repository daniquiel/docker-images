from helpers import show_room


def _exec(context: dict, param: str):
    show_room(context['room'])


cmd = {
    'name': 'kde som',
    'description': 'zobrazí opis miestnosti spolu s východmi a predmetmi, ktoré sa tam nachádzajú',
    'aliases': ("whereami", "rozhliadni sa", "look around"),
    'exec': _exec
}
