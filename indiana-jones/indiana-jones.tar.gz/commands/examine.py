from helpers import get_item_by_name


def _exec(context: dict, param: str):
    name = param
    # name of the item was not entered
    if not name:
        print("Neviem, čo chceš preskúmať.")
        return

    # search for item in room or backpack
    item = get_item_by_name(name, context['room']['items'] + context['backpack']['items'])

    # item is not found
    if item is None:
        print('Taký predmet tu nikde nevidím.')
        return

    print(item['description'])

cmd = {
    'name': 'preskumaj',
    'description': 'zobrazí opis predmetu v miestnosti alebo v batohu',
    'aliases': ('explore',),
    'exec': _exec
}
