def _exec(context: dict, param: str):
    print("Zoznam možných príkazov:")
    for cmd in context['commands']:
        print(f'* {cmd["name"]} - {cmd["description"]}')


cmd = {
    'name': 'prikazy',
    'description': 'zobrazí dostupné príkazy',
    'aliases': ("commands", "help", "?", "pomoc"),
    'exec': _exec
}
