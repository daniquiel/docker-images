from helpers import get_item_by_name


def _exec(context: dict, param: str):
    backpack = context['backpack']
    room = context['room']
    name = param

    # name was not entered
    if not name:
        print("Neviem čo chceš položiť.")
        return

    # search backpack for items
    item = get_item_by_name(name, backpack['items'])

    if item is None:
        print("Taký predmet pri sebe nemáš.")
        return

    # save to history
    context['history'].append(f'{cmd["name"]} {param}')

    # take item away
    backpack['items'].remove(item)
    room['items'].append(item)
    print(f"Predmet {name} si dal preč z batohu.")


cmd = {
    'name': 'poloz',
    'description': 'zoberie vec z batohu a položí ju do miestnosti',
    'aliases': ('put',),
    'exec': _exec
}
