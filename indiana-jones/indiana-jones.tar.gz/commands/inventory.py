def _exec(context: dict, param: str):
    # backpack = context['backpack']
    if not context['backpack']['items']:
        print("Batoh je prázdny.")
    else:
        print("V batohu máš:")
        for item in context['backpack']['items']:
            print(f"* {item['name']}")


cmd = {
    'name': 'inventar',
    'description': 'zobrazí veci uložené v batohu',
    'aliases': ("inventory", "inv", "i"),
    'exec': _exec
}
