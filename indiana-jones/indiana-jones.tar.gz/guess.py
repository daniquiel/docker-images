#!/usr/bin/env python3
import random


def play_game(secret):
    print("Myslím si číslo od 1 do 20")
    counter = 5
    tip = None

    while tip != secret and counter > 0:
        tip = input("Tvoj tip: ")
        tip = int(tip)
        if tip < secret:
            print("Hmm... moje číslo je väčšie ako tvoje.")
            counter -= 1
        elif tip > secret:
            print("Hmm... moje číslo je menšie ako tvoje.")
            counter -= 1
        else:
            print("Ta ty genius!")
            break
    else:
        print(f'Ta ty šaľeny, šak to bulo {secret}')


if __name__ == '__main__':
    game_continue = "a"
    while game_continue in ("a", "ano"):
        play_game(random.randint(1, 20))
        game_continue = input("Chceš pokračovať? (a/n)").strip().lower()

print("Tato hra nevznikla za podpory Europskej Unie ani ziadneho regionalneho fondu.")
