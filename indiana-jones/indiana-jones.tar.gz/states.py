# main state, when game is playing
PLAYING = 'playing'

# when QUIT command was entered
QUIT = 'quit'

# when player wins the game
WIN = 'well done'

# player died in game
DEAD = 'dead'
