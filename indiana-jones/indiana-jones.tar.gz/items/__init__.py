from .coin import coin
from .canister import canister
from .figa import figa
from .fire_extinguisher import fire_extinguisher
from .matches import matches
from .newspaper import newspaper
from .door import door

from .features import MOVABLE, USABLE
