from helpers import get_item_by_name
from .door import SOAKED, BURNING
from .features import MOVABLE, USABLE


def _use(context: dict) -> None:
    door = get_item_by_name('dvere', context['room']['items'])

    if door is None or door['state'] is not SOAKED:
        print("Zahrkal si si s krabičkou a áno, sú tam naozaj nejaké zápalky. Otvoril si ju a napočítal si rovné 3.")
        return

    matches['features'].remove(USABLE)
    door['state'] = BURNING
    door['description'] = 'Veľké masívne dubové dvere zachvátené obrovským výdatným plameňom.'
    door['name'] = 'horiace dvere'
    print('Škrtol si zápalkou a priložil si ju k nasiaknutým dubovým masívnym dverám. Tie okamžite vzplanuli'
          ' obrovským plameňom. ')


matches = {
    'name': 'zapalky',
    'description': 'Safety match zápalky. Zahrkal si krabičkou a po jej otvorení si našiel len tri.',
    'features': [MOVABLE, USABLE],
    'use': _use
}
