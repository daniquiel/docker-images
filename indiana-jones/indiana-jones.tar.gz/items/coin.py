from .features import MOVABLE

coin = {
    'name': 'minca',
    'description': 'Zlatá minca.',
    'features': [MOVABLE]
}