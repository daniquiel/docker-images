from .features import MOVABLE, USABLE

SOAKED = 'soaked'
NORMAL = 'normal'
BURNING = 'burning'

door = {
    'name': 'dvere',
    'description': 'Veľké masívne dubové dvere. Len tak niečo a niekto s nimi nepohne, keď sú zamknuté. A to teda sú.',
    'features': [USABLE, MOVABLE],
    'state': [NORMAL]
}
