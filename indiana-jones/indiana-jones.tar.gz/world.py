from items import matches, fire_extinguisher, canister, newspaper, door

world = [
    {
        "name": "dungeon",
        "description": 'Nachádzaš sa v tmavej zatuchnutej miestnosti. Na kamenných stenách sa nenachádza žiadne okno, '
                       'čo dáva tušiť, že si niekoľko metrov pod zemou. Žeby košický hrad? Aj to je možné, ti '
                       'prebleslo hlavou.',
        "items": [
            # commented out due to TypeError: Object of type function is not JSON serializable
            # matches,
            # fire_extinguisher,
            # canister,
            # newspaper,
            door
        ],
        "exits": {
            'north': None,
            'south': None,
            'east': None,
            'west': None
        }
    },
    {
        'name': 'garden',
        'description': 'Značne neudržiavaný priestor, ktorý sa určite pred pár rokmi volal záhradka.',
        'items': [],
        'exits': {
            'west': 'dungeon',
            'south': 'hell',
            'north': 'heaven',
            'east': None
        }
    },
    {
        'name': 'heaven',
        'description': 'Ultimatny stav, tu sa chces dostat.',
        'items': [],
        'exits': {
            'west': None,
            'south': 'garden',
            'north': None,
            'east': None
        }
    },
    {
        'name': 'hell',
        'description': 'Ultimatny stav zatratenia.',
        'items': [],
        'exits': {
            'west': None,
            'south': None,
            'north': 'garden',
            'east': None
        }
    }

]
